
# Change Log

All notable changes to this project will be documented in this file.


# [1.0.3](https://github.com/okx/js-wallet-sdk) (2024-08-20)

### Fix

- **coin-ton:** upgrade private key verification ([](https://github.com/okx/js-wallet-sdk))


# [1.0.1](https://github.com/okx/js-wallet-sdk) (2024-08-15)

### Feature

- **coin-ton:** support ton ([1.0.1](https://github.com/okx/js-wallet-sdk))
